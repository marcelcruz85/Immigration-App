email_registration
==================

The Email Registration module for DrupalGap.

1. Enable the "DrupalGap Email Registration" module on your Drupal site.
   This is included as a sub module within the DrupalGap module.
2. Download this module to your app/modules folder.
3. Enable the module within your app's settings.js file:

```   
Drupal.modules.contrib['email_registration'] = {};
```
